import React,{useState} from 'react';
import TextInput from './TextInput';
// Create();
function Memo  () {
    // Get();
    
    return (
        <div>
            <h1>Memo</h1>
            <TextInput></TextInput>
        </div>
    );
};

export default Memo;